#include "stdafx.h"
#include "GameObject/CameraManager.h"


CCameraManager::CCameraManager( ) :
m_curCamera( nullptr )
{
}