#pragma once

enum GAMEOBJECT_PROPERTY
{
	REFLECTABLE_OBJECT = 1 << 0,
	REMOVE_ME = 1 << 1,
};